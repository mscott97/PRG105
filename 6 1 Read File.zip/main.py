def main():
  namesFlie =open(”names.txt”, “r”)
  
  line = namesFile.readline()
  
  while line != ””:
    print(line.rstrip(“\n”))
    line = namesFlie.readline()

main()